# ST5004CEM Coursework — Simple Version

Four small, independent programs. Each one is a single file that does
exactly what its task in the brief asks — nothing extra, no game, no
graphics. Read top to bottom, it's all one linear story per file.

## How to build and run each one

No CMake needed — just plain g++.

```
# Task 1: threading, mutex, semaphore, round-robin, race condition, deadlock
g++ -std=c++20 task1_threads/task1_threads.cpp -pthread -o task1
./task1

# Task 2: paging simulator (FIFO + LRU)
g++ -std=c++20 task2_memory/task2_memory.cpp -o task2
./task2

# Task 3: secure file system (auth, permissions, encryption, audit log)
g++ -std=c++20 task3_filesystem/task3_filesystem.cpp -o task3
./task3

# Task 4: real client-server over TCP sockets (needs 2 terminals)
g++ -std=c++20 task4_network/server.cpp -pthread -o server
g++ -std=c++20 task4_network/client.cpp -o client
./server          # terminal 1 -- leave running
./client           # terminal 2 -- run this (can run more than once at the same time)
```

(Task 4 uses `<sys/socket.h>` etc., so it needs Linux or macOS. On Windows use WSL.)

## What's in each file, in one sentence

- **`task1_threads.cpp`** — 4 threads share a printer (`std::mutex`) and 2
  parking spots (`std::counting_semaphore`); a round-robin scheduler runs
  3 fake processes; the same counter is incremented unsafely (wrong
  result — the race condition) vs. safely (correct, mutex-protected);
  two threads grab two shared locks together with `std::lock()` so they
  can never deadlock.
- **`task2_memory.cpp`** — runs the same page-request sequence through
  FIFO and LRU eviction, printing each hit/fault and the final fault
  count and hit ratio for both.
- **`task3_filesystem.cpp`** — `User` stores a password *hash*, never the
  real password; `File` has owner-vs-others read/write permissions and
  XOR encryption; `FileSystem` checks permissions before every action
  and logs every attempt (allowed or denied) with a timestamp.
- **`server.cpp` / `client.cpp`** — a real TCP server that spawns one
  thread per connected client, with a simple text protocol
  (`LOGIN`/`MSG`/`LIST`/`QUIT`); the client logs in and talks to it.

## Things worth saying honestly in your write-up
- The password "hash" is `std::hash<std::string>` — fast, but not a real
  cryptographic hash (no salt). A real system would use bcrypt/Argon2.
- The file "encryption" is a single-byte XOR cipher — easy to break if
  someone guesses one byte. A real system would use AES.
- The networking code is POSIX-only (no Windows sockets support).
